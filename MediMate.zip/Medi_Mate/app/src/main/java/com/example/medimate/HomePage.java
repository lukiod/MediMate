package com.example.medimate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class HomePage extends AppCompatActivity {

    private Button signout;
    private ImageView createalarm;
    private DatabaseReference databaseReference;
    private RecyclerView recyclerView;
    private AlarmAdapter adapter;
    private List<Alarm> alarmList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home_page);

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        signout = findViewById(R.id.signOutButton);
        createalarm = findViewById(R.id.add_alarm);

        // Initialize the list to hold alarm data
        alarmList = new ArrayList<>();

        // Initialize the adapter
        adapter = new AlarmAdapter(this, alarmList);
        recyclerView.setAdapter(adapter);

        // Get current user
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            // Get reference to user's alarms
            databaseReference = FirebaseDatabase.getInstance().getReference()
                    .child("Users")
                    .child(currentUser.getUid())
                    .child("Alarms");

            // Fetch and display alarms
            fetchAlarms();
        }

        signout.setOnClickListener(v -> {
            // Sign out user
            signOut();
        });

        createalarm.setOnClickListener(v -> {
            Intent intent = new Intent(HomePage.this, CreateAlarmActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void fetchAlarms() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                alarmList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Alarm alarm = snapshot.getValue(Alarm.class);
                    if (alarm != null) {
                        alarmList.add(alarm);
                    }
                }
                adapter.notifyDataSetChanged(); // Notify adapter of data change
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
                Toast.makeText(HomePage.this, "Failed to fetch alarms: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void signOut() {
        FirebaseAuth.getInstance().signOut();
        // Navigate to your sign in or main activity
        Intent intent = new Intent(HomePage.this, LoginActivity.class);
        startActivity(intent);
        finish(); // Close the current activity
    }
}

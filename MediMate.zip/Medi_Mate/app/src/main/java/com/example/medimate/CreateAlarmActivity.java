package com.example.medimate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CreateAlarmActivity extends AppCompatActivity {

    private TimePicker timePicker;
    private EditText medicineEditText;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_alarm);

        timePicker = findViewById(R.id.timePicker);
        medicineEditText = findViewById(R.id.medicineEditText);

        // Get Firebase references
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(mAuth.getCurrentUser().getUid());

        // Set click listener for save button
        Button saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveAlarm();
            }
        });
    }

    public void saveAlarm() {
        // Get selected time from TimePicker
        int hour = timePicker.getCurrentHour();
        int minute = timePicker.getCurrentMinute();

        String time = String.format("%02d%02d", hour, minute);
        String medicineName = medicineEditText.getText().toString().trim();

        if (TextUtils.isEmpty(medicineName)) {
            Toast.makeText(this, "Please enter a medicine name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Generate unique alarm ID
        String alarmId = databaseReference.child("Alarms").push().getKey();

        // Create alarm object with time and medicine name
        Alarm alarm = new Alarm(time, medicineName);

        // Save alarm under current user's Alarms node
        databaseReference.child("Alarms").child(alarmId).setValue(alarm)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(CreateAlarmActivity.this, "Alarm saved successfully!", Toast.LENGTH_SHORT).show();
                    finish(); // Close activity after successful save
                })
                .addOnFailureListener(e -> Toast.makeText(CreateAlarmActivity.this, "Failed to save alarm: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    // Class representing an alarm object
    static class Alarm {
        public String time;
        public String medicineName;

        public Alarm(String time, String medicineName) {
            this.time = time;
            this.medicineName = medicineName;
        }
    }
}

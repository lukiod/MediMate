package com.example.medimate;

public class Alarm {
    private String id;
    private String time;
    private String medicineName;

    public Alarm() {
        // Default constructor required for Firebase deserialization
    }

    public Alarm(String time, String medicineName) {
        this.id = id;
        this.time = time;
        this.medicineName = medicineName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }
}
